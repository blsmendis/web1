import React, { useState } from 'react';
import { Upload, Link as LinkIcon, PlayCircle } from 'lucide-react';

interface PlaylistManagerProps {
  onLoadPlaylist: (url: string | File) => void;
  onLoadDemo: () => void;
}

const PlaylistManager: React.FC<PlaylistManagerProps> = ({ onLoadPlaylist, onLoadDemo }) => {
  const [url, setUrl] = useState('');
  const [activeTab, setActiveTab] = useState<'url' | 'file'>('url');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url) onLoadPlaylist(url);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onLoadPlaylist(e.target.files[0]);
    }
  };

  return (
    <div className="absolute inset-0 bg-slate-900 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-800 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-700">
        <div className="p-8 text-center border-b border-slate-700 bg-gradient-to-br from-slate-800 to-slate-900">
          <h1 className="text-3xl font-bold text-white mb-2 tracking-tight">TiviWeb</h1>
          <p className="text-slate-400 text-sm">Next-Gen Web IPTV Player</p>
        </div>

        <div className="p-6 space-y-6">
            <div className="flex bg-slate-900 rounded-lg p-1">
                <button 
                    onClick={() => setActiveTab('url')}
                    className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${activeTab === 'url' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                    M3U URL
                </button>
                <button 
                    onClick={() => setActiveTab('file')}
                    className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${activeTab === 'file' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                    Upload File
                </button>
            </div>

            {activeTab === 'url' ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="relative">
                        <LinkIcon className="absolute left-3 top-3.5 text-slate-500" size={18} />
                        <input
                            type="url"
                            placeholder="https://example.com/playlist.m3u"
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg py-3 pl-10 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 placeholder-slate-600"
                            value={url}
                            onChange={(e) => setUrl(e.target.value)}
                            required
                        />
                    </div>
                    <button 
                        type="submit" 
                        className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold py-3 rounded-lg transition-colors shadow-lg shadow-blue-900/20"
                    >
                        Load Playlist
                    </button>
                </form>
            ) : (
                 <div className="border-2 border-dashed border-slate-600 rounded-lg p-8 text-center hover:bg-slate-700/30 transition-colors relative">
                    <input 
                        type="file" 
                        accept=".m3u,.m3u8" 
                        className="absolute inset-0 opacity-0 cursor-pointer"
                        onChange={handleFileChange}
                    />
                    <Upload className="mx-auto text-slate-400 mb-2" size={32} />
                    <p className="text-sm text-slate-300">Click or drag M3U file here</p>
                 </div>
            )}

            <div className="relative">
                <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-700"></div>
                </div>
                <div className="relative flex justify-center text-xs">
                    <span className="px-2 bg-slate-800 text-slate-500">OR</span>
                </div>
            </div>

            <button 
                onClick={onLoadDemo}
                className="w-full bg-emerald-600/10 hover:bg-emerald-600/20 border border-emerald-600/30 text-emerald-400 font-medium py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
                <PlayCircle size={18} />
                Try Demo Playlist
            </button>
        </div>
        <div className="bg-slate-900/50 p-4 text-center text-xs text-slate-500">
             Supports M3U & M3U8 playlists. <br/> Gemini AI features require API Key.
        </div>
      </div>
    </div>
  );
};

export default PlaylistManager;