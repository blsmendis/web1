import React, { useEffect, useState } from 'react';
import { Channel } from '../types';
import { Maximize, Minimize, Volume2, VolumeX, List, Settings } from 'lucide-react';

interface ControlsProps {
  channel: Channel | null;
  onToggleGuide: () => void;
  onReset: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

const Controls: React.FC<ControlsProps> = ({ channel, onToggleGuide, onReset, isMuted, onToggleMute }) => {
  const [visible, setVisible] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    // Fixed: Use ReturnType<typeof setTimeout> instead of NodeJS.Timeout to avoid namespace error in browser environments
    let timeout: ReturnType<typeof setTimeout>;
    const resetTimer = () => {
      setVisible(true);
      clearTimeout(timeout);
      timeout = setTimeout(() => setVisible(false), 4000);
    };

    window.addEventListener('mousemove', resetTimer);
    window.addEventListener('click', resetTimer);
    window.addEventListener('keydown', resetTimer);
    
    resetTimer();

    return () => {
      window.removeEventListener('mousemove', resetTimer);
      window.removeEventListener('click', resetTimer);
      window.removeEventListener('keydown', resetTimer);
      clearTimeout(timeout);
    };
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
        setIsFullscreen(false);
      }
    }
  };

  if (!visible) return null;

  return (
    <div className="absolute inset-0 flex flex-col justify-between p-8 bg-gradient-to-b from-black/60 via-transparent to-black/80 transition-opacity duration-300 pointer-events-none z-30">
        
        {/* Top Bar */}
        <div className="flex justify-between items-start pointer-events-auto">
             <div className="flex flex-col">
                {channel && (
                    <>
                        <h2 className="text-3xl font-bold text-white drop-shadow-md">{channel.name}</h2>
                        <span className="text-slate-300 text-sm bg-blue-600/80 px-2 py-0.5 rounded w-fit mt-1">{channel.group}</span>
                    </>
                )}
             </div>
             <button 
                onClick={onReset}
                className="text-white/70 hover:text-white hover:bg-white/10 p-2 rounded-full transition-all"
                title="Change Playlist"
             >
                 <Settings size={24} />
             </button>
        </div>

        {/* Bottom Bar */}
        <div className="flex items-center gap-6 pointer-events-auto">
            <button 
                onClick={onToggleGuide}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-lg font-semibold shadow-lg shadow-blue-900/30 transition-all transform hover:scale-105"
            >
                <List size={20} />
                TV Guide
            </button>

            <div className="flex-1"></div>

            <button onClick={onToggleMute} className="text-white hover:text-blue-400 p-2 transition-colors">
                {isMuted ? <VolumeX size={28} /> : <Volume2 size={28} />}
            </button>

            <button onClick={toggleFullscreen} className="text-white hover:text-blue-400 p-2 transition-colors">
                {isFullscreen ? <Minimize size={28} /> : <Maximize size={28} />}
            </button>
        </div>
    </div>
  );
};

export default Controls;