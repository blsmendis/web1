import React, { useEffect, useRef, useState } from 'react';
import { Channel, ChannelGroup, EPGProgram } from '../types';
import { format, addMinutes, startOfHour } from 'date-fns';
import { Play, Info } from 'lucide-react';
import { getProgramInfo } from '../services/geminiService';

interface GuideProps {
  groups: ChannelGroup[];
  currentChannel: Channel | null;
  onSelectChannel: (channel: Channel) => void;
  onClose: () => void;
  visible: boolean;
}

const HOURS_TO_SHOW = 4;
const CELL_WIDTH = 250; // pixels per hour roughly

const Guide: React.FC<GuideProps> = ({ groups, currentChannel, onSelectChannel, onClose, visible }) => {
  const [selectedGroupIndex, setSelectedGroupIndex] = useState(0);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [infoPanelData, setInfoPanelData] = useState<{title: string, desc: string} | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Auto-scroll to current channel group if possible
  useEffect(() => {
    if (currentChannel && groups.length > 0) {
      const idx = groups.findIndex(g => g.channels.some(c => c.id === currentChannel.id));
      if (idx !== -1) setSelectedGroupIndex(idx);
    }
  }, [currentChannel, groups]);

  // Clock
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const currentGroup = groups[selectedGroupIndex];
  
  // Mock EPG Data Generation
  const getMockProgram = (channel: Channel, timeOffset: number): EPGProgram => {
    const start = addMinutes(startOfHour(currentTime), timeOffset * 60);
    return {
      id: `${channel.id}-${timeOffset}`,
      channelId: channel.id,
      title: `${channel.name} Program ${timeOffset + 1}`,
      description: `This is a simulated description for a program on ${channel.name}.`,
      start,
      end: addMinutes(start, 60)
    };
  };

  const handleAiInfo = async (channel: Channel, programName: string) => {
    setIsAiLoading(true);
    const info = await getProgramInfo(channel.name, programName);
    setInfoPanelData({ title: programName, desc: info });
    setIsAiLoading(false);
  };

  if (!visible) return null;

  return (
    <div className="absolute inset-0 z-40 bg-slate-900/95 text-white flex flex-col font-sans backdrop-blur-sm transition-opacity duration-200">
      
      {/* Header / Info Panel */}
      <div className="h-48 border-b border-slate-700 p-6 flex gap-6 bg-slate-900 shadow-xl z-20">
        <div className="flex-shrink-0">
            {currentChannel?.logo ? (
                <img src={currentChannel.logo} alt="Logo" className="w-32 h-32 object-contain bg-slate-800 rounded-lg p-2" />
            ) : (
                <div className="w-32 h-32 bg-slate-800 rounded-lg flex items-center justify-center text-4xl font-bold text-slate-600">
                    TV
                </div>
            )}
        </div>
        <div className="flex-1 flex flex-col justify-center">
            <h1 className="text-3xl font-bold mb-2 text-white">
                {infoPanelData ? infoPanelData.title : (currentChannel ? currentChannel.name : 'Select a Channel')}
            </h1>
            <p className="text-slate-400 text-lg max-w-4xl line-clamp-3">
                {infoPanelData ? infoPanelData.desc : (currentChannel ? `Now watching ${currentChannel.name}. Press AI Info for details.` : 'Welcome to TiviWeb.')}
            </p>
            <div className="mt-4 flex gap-3">
               {currentChannel && (
                  <button 
                    onClick={() => handleAiInfo(currentChannel, `${currentChannel.name} Live Stream`)}
                    disabled={isAiLoading}
                    className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded font-medium disabled:opacity-50 transition-colors"
                  >
                    <Info size={18} />
                    {isAiLoading ? 'Analyzing...' : 'AI Insights'}
                  </button>
               )}
            </div>
        </div>
        <div className="text-right">
             <div className="text-4xl font-light">{format(currentTime, 'HH:mm')}</div>
             <div className="text-slate-400">{format(currentTime, 'EEEE, MMM d')}</div>
        </div>
      </div>

      {/* Main Content Area: Groups + Grid */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Groups Sidebar */}
        <div className="w-64 bg-slate-800 flex flex-col border-r border-slate-700 overflow-y-auto no-scrollbar">
            {groups.map((group, idx) => (
                <button
                    key={group.name}
                    onClick={() => setSelectedGroupIndex(idx)}
                    className={`p-4 text-left hover:bg-slate-700 transition-colors ${
                        selectedGroupIndex === idx 
                        ? 'bg-blue-600 text-white font-semibold' 
                        : 'text-slate-400'
                    }`}
                >
                    {group.name}
                    <span className="float-right text-xs opacity-50 mt-1">{group.channels.length}</span>
                </button>
            ))}
        </div>

        {/* Channels & EPG Grid */}
        <div className="flex-1 flex flex-col overflow-hidden bg-slate-900">
            {/* Time Header */}
            <div className="flex border-b border-slate-800 h-10 items-center bg-slate-900 sticky top-0 z-10">
                <div className="w-64 flex-shrink-0 px-4 text-slate-500 text-sm font-medium border-r border-slate-800 h-full flex items-center bg-slate-900">
                    Channel
                </div>
                {Array.from({ length: HOURS_TO_SHOW }).map((_, i) => (
                    <div key={i} className="flex-shrink-0 border-r border-slate-800 text-slate-500 text-sm pl-2 flex items-center" style={{ width: CELL_WIDTH }}>
                        {format(addMinutes(startOfHour(currentTime), i * 60), 'HH:mm')}
                    </div>
                ))}
            </div>

            {/* Channels Rows */}
            <div className="flex-1 overflow-y-auto overflow-x-hidden no-scrollbar pb-20">
                {currentGroup?.channels.map((channel) => (
                    <div 
                        key={channel.id} 
                        className={`flex h-16 border-b border-slate-800 hover:bg-slate-800 transition-colors group cursor-pointer ${currentChannel?.id === channel.id ? 'bg-slate-800' : ''}`}
                        onClick={() => {
                            onSelectChannel(channel);
                            setInfoPanelData(null); // Clear old info
                        }}
                    >
                        {/* Channel Name Column */}
                        <div className={`w-64 flex-shrink-0 flex items-center px-4 border-r border-slate-800 gap-3 ${currentChannel?.id === channel.id ? 'text-blue-400 font-bold' : 'text-slate-300'}`}>
                             {currentChannel?.id === channel.id && <Play size={16} className="fill-current" />}
                             <span className="truncate">{channel.name}</span>
                        </div>

                        {/* EPG Timeline Cells (Mocked) */}
                        {Array.from({ length: HOURS_TO_SHOW }).map((_, i) => {
                            const prog = getMockProgram(channel, i);
                            return (
                                <div 
                                    key={i} 
                                    className="flex-shrink-0 border-r border-slate-800 p-2 overflow-hidden relative"
                                    style={{ width: CELL_WIDTH }}
                                >
                                    <div className="bg-slate-700/30 rounded h-full p-2 text-xs text-slate-400 hover:bg-slate-700/60 transition-colors">
                                        <div className="font-semibold text-slate-300 truncate">{prog.title}</div>
                                        <div className="truncate mt-1 opacity-70">{format(prog.start, 'HH:mm')} - {format(prog.end, 'HH:mm')}</div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ))}
            </div>
        </div>
      </div>
      
      {/* Footer Hint */}
      <div className="absolute bottom-6 right-6 text-slate-500 text-sm bg-black/50 px-3 py-1 rounded backdrop-blur">
          Press <span className="font-bold text-white">ESC</span> or <span className="font-bold text-white">Back</span> to return to player
      </div>
    </div>
  );
};

export default Guide;