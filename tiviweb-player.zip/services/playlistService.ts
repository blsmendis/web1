import { Channel, ChannelGroup } from '../types';

export const parseM3U = (content: string): ChannelGroup[] => {
  const lines = content.split('\n');
  const channels: Channel[] = [];
  let currentChannel: Partial<Channel> = {};

  lines.forEach((line) => {
    line = line.trim();
    if (line.startsWith('#EXTINF:')) {
      // Basic parsing logic for EXTINF
      const info = line.substring(8);
      const props = info.split(',');
      const name = props[props.length - 1]?.trim() || 'Unknown Channel';
      
      // Attempt to extract metadata
      const logoMatch = line.match(/tvg-logo="([^"]*)"/);
      const groupMatch = line.match(/group-title="([^"]*)"/);
      const idMatch = line.match(/tvg-id="([^"]*)"/);

      currentChannel = {
        id: idMatch ? idMatch[1] : `ch-${channels.length + 1}`,
        name: name,
        logo: logoMatch ? logoMatch[1] : undefined,
        group: groupMatch ? groupMatch[1] : 'Uncategorized',
      };
    } else if (line.startsWith('http')) {
      if (currentChannel.name) {
        channels.push({
          ...currentChannel,
          url: line,
        } as Channel);
        currentChannel = {};
      }
    }
  });

  return groupChannels(channels);
};

export const groupChannels = (channels: Channel[]): ChannelGroup[] => {
  const groups: Record<string, Channel[]> = {};
  
  // Add "All Channels" group
  groups['All Channels'] = [...channels];

  channels.forEach(ch => {
    const g = ch.group || 'Uncategorized';
    if (!groups[g]) {
      groups[g] = [];
    }
    groups[g].push(ch);
  });

  return Object.keys(groups).map(name => ({
    name,
    channels: groups[name]
  }));
};