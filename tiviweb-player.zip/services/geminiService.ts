import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({ apiKey });
}

export const getProgramInfo = async (channelName: string, programTitle?: string): Promise<string> => {
  if (!ai) return "Gemini API Key not configured. Please check your environment settings.";

  const prompt = programTitle 
    ? `Provide a short, engaging summary (max 2 sentences) and an IMDB-style rating for the show/movie "${programTitle}" currently playing on channel "${channelName}".`
    : `Tell me briefly what kind of content usually plays on the channel "${channelName}" and give it a genre tag. Keep it under 50 words.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || "No information available.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Unable to fetch program information at this time.";
  }
};
